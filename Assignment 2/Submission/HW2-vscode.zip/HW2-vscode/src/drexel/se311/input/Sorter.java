package drexel.se311.input;


public abstract class Sorter {


    public Sorter(){
    }

    public abstract void sort (LineStorage lineStorage);

}
