To run my program, simply run the main() method in the MainDriver class.
You can then interact with the program via the console.
Please re-run the program for each search attempt.

Please note that currently the program is case-sensitive and only works via the console.
This will be changed for customization in future revisions.