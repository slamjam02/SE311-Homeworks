package drexel.se311.kwicserver;


public abstract class Alphabetizer {


    public Alphabetizer(){
    }

    public abstract void sort (LineStorage lineStorage);

}
